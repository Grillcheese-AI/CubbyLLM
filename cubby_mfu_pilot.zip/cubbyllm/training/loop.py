"""TrainLoop — the training driver.

Wired: STANDALONE — orchestration, not the forward path.

Holds the model, a manifest-pinned ``DataPipeline``, and the ``Hardener`` that
H0 proved essential — so anti-drift regularization is a structural part of the
loop, not an afterthought. ``step`` does one gradient step: forward -> next-token
cross-entropy (over the retrieval head's local candidate set) + the hardener's
drift penalty -> backward -> optimizer step. The hardener contribution is what
makes this theta=f(c) loop retain prior contexts rather than overwrite them.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from ..core.protocols import Wiring

if TYPE_CHECKING:
    from ..core.generation import Hardener, ParameterGenerator
    from ..model.assembly import CubbyModel
    from .data import DataPipeline


class TrainLoop:
    """Drives training with hardened context-conditioned generation."""

    def __init__(
        self,
        model: "CubbyModel",
        data: "DataPipeline",
        hardener: "Hardener",
        lr: float = 1e-3,
        batch_size: int = 8,
        seq_len: int = 16,
        device=None,
        amp: bool = True,
        grad_clip: float = 1.0,
        warmup: int = 0,
        total_steps: int = 0,
        min_lr_ratio: float = 0.1,
        reduce_grads: bool = False,
        bind_weight: float = 0.0,
        bind_n: int = 16,
    ) -> None:
        import torch

        self.model = model
        self.data = data
        self.hardener = hardener
        self.batch_size = int(batch_size)
        self.seq_len = int(seq_len)
        # device: None keeps CPU behavior; pass a resolved device (e.g. cuda) to
        # train on GPU. The model must already be moved there (see core.device).
        self.device = device
        # amp: bf16 autocast, applied ONLY on CUDA (halves memory, ~2-3x faster at
        # 2B scale). bf16 needs no GradScaler; weights stay fp32. No-op off CUDA.
        self.amp = bool(amp)
        # grad_clip: global-norm clip before opt.step — REQUIRED for stability with
        # the generated θ=f(c) memory (a single bad batch otherwise detonates the
        # loss). warmup: linear LR ramp over the first N steps (early-divergence guard).
        self.grad_clip = float(grad_clip)
        self.warmup = int(warmup)
        # total_steps>0 turns on cosine LR decay (warmup -> peak -> min_lr_ratio*lr
        # over the run). 0 keeps the flat-after-warmup schedule. On resume, set
        # _nstep to the global step so the schedule continues (see train_colab).
        self.total_steps = int(total_steps)
        self.min_lr_ratio = float(min_lr_ratio)
        # reduce_grads: DDP data-parallel — average .grad across ranks after
        # backward (manual, since CubbyModel is not an nn.Module to hand to DDP).
        self.reduce_grads = bool(reduce_grads)
        # bind_weight>0 adds the VSA binding aux loss (shapes the trunk's h to be
        # bindable). Parameter-free: N fixed role keys, block-code bind/unbind.
        self.bind_weight = float(bind_weight)
        self.bind_n = int(bind_n)
        self._roles = None
        self._last_bind = 0.0
        self._base_lr = float(lr)
        self._nstep = 0
        self.opt = torch.optim.Adam(list(model.parameters()), lr=lr)
        self._batches = data.batches(self.batch_size, self.seq_len)

    def _generator(self) -> "ParameterGenerator | None":
        return getattr(self.model.memory, "generator", None)

    def _lr_at(self, t: int):
        """LR at global step ``t``: linear warmup, then cosine decay to
        ``min_lr_ratio*base`` if total_steps is set, else hold at base. Returns
        None when no schedule is configured (leaves the optimizer LR untouched)."""
        if not self.warmup and not self.total_steps:
            return None
        base = self._base_lr
        if self.warmup and t <= self.warmup:
            return base * t / self.warmup
        if self.total_steps and self.total_steps > self.warmup:
            import math
            prog = min(1.0, (t - self.warmup) / max(self.total_steps - self.warmup, 1))
            floor = base * self.min_lr_ratio
            return floor + 0.5 * (base - floor) * (1.0 + math.cos(math.pi * prog))
        return base                                          # warmup-only: hold after ramp

    def step(self) -> float:
        """One training step. Returns the scalar loss (CE + hardener penalty)."""
        import contextlib

        import torch
        import torch.nn.functional as F

        x, y = next(self._batches)
        if self.device is not None:                          # GPU: batches are CPU
            x, y = x.to(self.device), y.to(self.device)
        # bf16 autocast on CUDA only; forward + loss run mixed-precision, backward
        # and the fp32 master weights are untouched (bf16 range needs no scaler).
        use_amp = self.amp and self.device is not None and self.device.type == "cuda"
        actx = (torch.autocast(device_type="cuda", dtype=torch.bfloat16)
                if use_amp else contextlib.nullcontext())
        h = None
        with actx:
            if self.bind_weight > 0:                          # need the trunk features
                h = self.model.features(x)
                logits = self.model.logits_from(h)
            else:
                logits = self.model.forward(x)               # (B, S, V)
            vocab = logits.shape[-1]
            loss = F.cross_entropy(logits.reshape(-1, vocab), y.reshape(-1))
            gen = self._generator()
            if gen is not None:
                pen = self.hardener.penalty(gen)
                if torch.is_tensor(pen):
                    loss = loss + pen
        if self.bind_weight > 0 and h is not None:            # VSA binding aux loss (fp32)
            from ..model.binding.torch_ops import binding_aux_loss, make_roles
            hf = h.float()
            if self._roles is None or self._roles.shape[-1] != hf.shape[-1]:
                self._roles = make_roles(self.bind_n, hf.shape[-1], hf.device)
            bl = binding_aux_loss(hf, self._roles)
            self._last_bind = float(bl.detach())
            loss = loss + self.bind_weight * bl

        self._nstep += 1
        lr = self._lr_at(self._nstep)                            # warmup + cosine decay
        if lr is not None:
            for g in self.opt.param_groups:
                g["lr"] = lr

        self.opt.zero_grad()
        loss.backward()
        if self.reduce_grads:                                    # DDP: average grads across ranks
            import torch.distributed as dist
            ws = dist.get_world_size()
            for p in self.model.parameters():
                if p.grad is not None:
                    dist.all_reduce(p.grad, op=dist.ReduceOp.SUM)
                    p.grad /= ws
        if self.grad_clip and self.grad_clip > 0:                # kill explosion spikes (after reduce)
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
        self.opt.step()
        return float(loss.detach())


__wiring__ = Wiring.STANDALONE
