"""MinGRUBackbone — the pure-recurrence baseline (H-D1 2026-07-23).

Wired: WIRED — a tested, selectable backbone. NOTE: no longer THE default. H-D1
picked MinGRU on bpc, which is blind to retrieval; the H-D4 needle A/B
(2026-08-04) then showed a windowed-attention hybrid recalls ~98% inside its
window vs ~32% here, at the same bounded state, so ``HybridBackbone`` is now the
default (it embeds this same MinGRU recurrence on its non-attention layers). This
class stays as the baseline and the fallback where attention isn't wanted.

Resolved by the in-architecture bake-off (``validation/exp_d1b_backbone_bakeoff``):
in the real CubbyModel on subword TinyStories, gated recurrence beat the
attention-free Q=K recurrence and softmax attention by ~10% bpc; MinGRU matched
GRU's quality (1.308 vs 1.300 bpc — within single-run noise) at 25% fewer
backbone params, plus a log-domain PARALLEL SCAN (throughput at scale, where
GRU's kernel is sequential) and continuity with cubby-lm. User decision: MinGRU.

Trunk: N layers of [RMSNorm -> MinGRU recurrence -> +res, RMSNorm -> SwiGLU ->
+res]. The recurrence is an elementwise gate + Heinsen-2023 log-domain parallel
scan (cubby-lm form). Satisfies ``Backbone``: forward((B,S,d)) -> (B,S,d).
"""
from __future__ import annotations

from typing import TYPE_CHECKING

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.checkpoint

from ...core.protocols import Wiring

if TYPE_CHECKING:
    pass


class _RMSNorm(nn.Module):
    def __init__(self, d: int):
        super().__init__()
        self.w = nn.Parameter(torch.ones(d))

    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + 1e-6) * self.w


class _SwiGLU(nn.Module):
    def __init__(self, d: int, mult: int = 2):
        super().__init__()
        h = d * mult
        self.g = nn.Linear(d, h, bias=False)
        self.u = nn.Linear(d, h, bias=False)
        self.o = nn.Linear(h, d, bias=False)

    def forward(self, x):
        return self.o(F.silu(self.g(x)) * self.u(x))


def _sequential_scan(x_scan: "torch.Tensor", a: "torch.Tensor") -> "torch.Tensor":
    """Exact recurrence h_t = a_t*h_{t-1} + x_t as an O(S) loop of mul/add only.

    Used on DirectML, whose op set does not cover ``logcumsumexp`` (the parallel
    scan below). Same result, GPU-resident; slower per step but correct."""
    B, S, d = x_scan.shape
    h = torch.zeros(B, d, device=x_scan.device, dtype=x_scan.dtype)
    out = []
    for t in range(S):
        h = a[:, t] * h + x_scan[:, t]
        out.append(h)
    return torch.stack(out, dim=1)


def _log_domain_scan(x_scan: "torch.Tensor", a: "torch.Tensor") -> "torch.Tensor":
    """Causal linear-RNN scan h_t = a_t*h_{t-1} + x_t via Heinsen 2023 log-domain
    parallel scan (O(log T) depth, sign-split for negative x).

    DirectML (device type 'privateuseone') lacks ``logcumsumexp``, so the exact
    sequential recurrence is used there instead — the only device-specific branch
    in the backbone, and it changes nothing on CPU/CUDA."""
    if x_scan.device.type == "privateuseone":
        return _sequential_scan(x_scan, a)
    log_a = a.clamp(min=1e-8).log()
    a_star = log_a.cumsum(dim=1)
    eps = 1e-30
    hp = (a_star + ((x_scan.clamp(min=0) + eps).log() - a_star).logcumsumexp(dim=1)).exp()
    hn = (a_star + (((-x_scan).clamp(min=0) + eps).log() - a_star).logcumsumexp(dim=1)).exp()
    return hp - hn


class _MinGRUMixer(nn.Module):
    def __init__(self, d: int):
        super().__init__()
        self.proj_g = nn.Linear(d, d)
        self.proj_v = nn.Linear(d, d)
        self.proj_d = nn.Linear(d, d)
        nn.init.constant_(self.proj_d.bias, 1.0)   # ~0.73 retention at init

    def forward(self, x):
        x_scan = torch.sigmoid(self.proj_g(x)) * torch.tanh(self.proj_v(x))
        a = 0.001 + 0.998 * torch.sigmoid(self.proj_d(x))
        return _log_domain_scan(x_scan, a)

    def step(self, x_t, h_prev=None):
        """ONE token, carrying state — the decode path. x_t: (B, d) -> (y, h).

        The parallel scan above is a TRAINING optimisation; the recurrence itself
        (h_t = a_t*h_{t-1} + x_t, h_0 = 0) is inherently sequential and O(1) per
        token in both compute and memory. That is the whole inference argument for
        this backbone, and without this method it is unrealised: generating with
        ``forward`` re-runs the entire prefix per token, which is O(S) work per
        token and strictly worse than a transformer with a KV cache.

        Must agree with ``forward`` to floating-point tolerance — see
        tests/model/test_mingru_decode.py, which is what makes any throughput
        comparison meaningful rather than a measurement of a different model.
        """
        x_scan = torch.sigmoid(self.proj_g(x_t)) * torch.tanh(self.proj_v(x_t))
        a = 0.001 + 0.998 * torch.sigmoid(self.proj_d(x_t))
        h = x_scan if h_prev is None else a * h_prev + x_scan
        return h, h


class MinGRUBackbone(nn.Module):
    """The default CubbyLLM backbone: a MinGRU + SwiGLU trunk.

    forward: (B, S, d_model) embeddings -> (B, S, d_model) hidden states.
    Conforms to ``cubbyllm.model.backbone.Backbone``.
    """

    def __init__(self, d_model: int, n_layers: int = 2,
                 grad_checkpoint: bool = False):
        super().__init__()
        self.d_model = int(d_model)
        self.n1 = nn.ModuleList([_RMSNorm(d_model) for _ in range(n_layers)])
        self.mix = nn.ModuleList([_MinGRUMixer(d_model) for _ in range(n_layers)])
        self.n2 = nn.ModuleList([_RMSNorm(d_model) for _ in range(n_layers)])
        self.ffn = nn.ModuleList([_SwiGLU(d_model) for _ in range(n_layers)])
        # grad_checkpoint: recompute each layer in backward instead of storing its
        # activations — the big activation-memory saver at 2B/deep (32 layers), so a
        # much larger batch fits. ~30% more compute; the batch win dominates.
        self.grad_checkpoint = bool(grad_checkpoint)

    @staticmethod
    def _layer(x, n1, m, n2, f):
        x = x + m(n1(x))
        x = x + f(n2(x))
        return x

    def step(self, x_t, states=None):
        """Decode one token. x_t: (B, d_model). states: list of per-layer (B, d)
        or None to start. Returns (y_t, new_states).

        Cost per token is O(d^2) and INDEPENDENT of how many tokens preceded it;
        the carried state is n_layers x (B, d) floats and does not grow. Compare a
        KV cache, which grows linearly in context. Never grad-checkpointed — this
        path is inference-only and runs under no_grad.
        """
        n = len(self.mix)
        states = [None] * n if states is None else states
        new_states = []
        for i in range(n):
            h, s = self.mix[i].step(self.n1[i](x_t), states[i])
            x_t = x_t + h
            x_t = x_t + self.ffn[i](self.n2[i](x_t))
            new_states.append(s)
        return x_t, new_states

    def forward(self, x: "torch.Tensor") -> "torch.Tensor":
        ckpt = self.grad_checkpoint and torch.is_grad_enabled()
        for n1, m, n2, f in zip(self.n1, self.mix, self.n2, self.ffn):
            if ckpt:
                x = torch.utils.checkpoint.checkpoint(
                    self._layer, x, n1, m, n2, f, use_reentrant=False)
            else:
                x = self._layer(x, n1, m, n2, f)
        return x


__wiring__ = Wiring.WIRED
